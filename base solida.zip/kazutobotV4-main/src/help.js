const help = (prefix) => { 
	return `   *🍁MENU SCREAMOBOT 🍁*
	
	
┏━━━━━━━━━━━━━━━━━━━━━┓
┃ *⚠️ SEM SPAM!! NAO LIGUE!!! ⚠️*
┃ *LEVAR BLOCK/BAN!!!*
┣━━━━°❀ *❬ SOBRE ❭* ❀°━━━━━━┛
┃
┃⊱❥ *LORDESCREAMOBOT*
┃⊱❥ *V 6.0*
┃⊱❥ *http://wa.me/5522999982383*
┃⊱❥ *Lorde Screamo*             
┃
┣━━°❀ ❬ *TENTANG BOT* ❭ ❀°━━┓
┃
┣⊱❥ *${prefix}speed* ✓ rapidez ✓
┃͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏ ͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏͏.
┣━━━━°❀ ❬ *MEDIA* ❭ ❀°━━━━━┓
┃
┣⊱❥ *${prefix}stiker* ✓ converta imagem ou gif em figurinha ✓
┣⊱❥ *${prefix}tsticker*
┣⊱❥ *${prefix}toimg* ✓ converta figurinhas em imagens✓
┣⊱❥ *${prefix}nulis*
┣⊱❥ *${prefix}ocr*
┣⊱❥ *${prefix}ytsearch*
┣⊱❥ *${prefix}ytmp3*
┣⊱❥ *${prefix}ytmp4*
┣⊱❥ *${prefix}tiktok*
┣⊱❥ *${prefix}tiktokstalk*
┣⊱❥ *${prefix}fototiktok*
┣⊱❥ *${prefix}igstalk*
┣⊱❥ *${prefix}image*
┣⊱❥ *${prefix}pinterest*
┣⊱❥ *${prefix}tts*
┣⊱❥ *${prefix}tes*
┣⊱❥ *${prefix}tep*
┣⊱❥ *${prefix}ttp*
┣⊱❥ *${prefix}meme*
┣⊱❥ *${prefix}memeindo*
┣⊱❥ *${prefix}ssweb*
┣⊱❥ *${prefix}walpaperhd*
┣⊱❥ *${prefix}randomcat*
┣⊱❥ *${prefix}joox*
┣⊱❥ *${prefix}inu*
┣⊱❥ *${prefix}elang*
┣⊱❥ *${prefix}unta*
┣⊱❥ *${prefix}anjing*
┣⊱❥ *${prefix}babi*
┣⊱❥ *${prefix}playstore*
┣⊱❥ *${prefix}url2image*
┣⊱❥ *${prefix}kbbi*
┣⊱❥ *${prefix}imoji*
┣⊱❥ *${prefix}wait*
┃
┣━━━━°❀ ❬ *CRIADOR* ❭ ❀°━━━━┓
┃
┣⊱❥ *${prefix}thunder*
┣⊱❥ *${prefix}tahta*
┣⊱❥ *${prefix}glitch <teks|teks>*
┣⊱❥ *${prefix}phlogo <teks|teks>*
┣⊱❥ *${prefix}wolflogo <teks|teks>*
┣⊱❥ *${prefix}wolflogo2 <teks|teks>*
┣⊱❥ *${prefix}quotemaker <tx|wtrmk|tema>*
┣⊱❥ *${prefix}galaxtext*
┣⊱❥ *${prefix}textdark*
┣⊱❥ *${prefix}textblue*
┣⊱❥ *${prefix}lovemake*
┣⊱❥ *${prefix}stiltext*
┣⊱❥ *${prefix}ninjalogo*
┣⊱❥ *${prefix}party*
┣⊱❥ *${prefix}rtext*
┣⊱❥ *${prefix}water*
┣⊱❥ *${prefix}lionlogo <teks|teks>*
┣⊱❥ *${prefix}textscreen*
┣⊱❥ *${prefix}text3d*
┣⊱❥ *${prefix}epep*
┣⊱❥ *${prefix}marvelogo <teks|teks>*
┣⊱❥ *${prefix}snow <teks|teks>*
┣⊱❥ *${prefix}firetext*
┃
┣━━━°❀ ❬ *DIVERSAO&JOGOS* ❭ ❀°━━━┓
┃
┣⊱❥ *${prefix}truth*
┣⊱❥ *${prefix}dare*
┣⊱❥ *${prefix}tebakgambar*
┣⊱❥ *${prefix}family100*
┣⊱❥ *${prefix}caklontong*
┣⊱❥ *${prefix}game*
┣⊱❥ *${prefix}primbonjodoh*
┣⊱❥ *${prefix}ramaljadian*
┣⊱❥ *${prefix}mlherolist*
┣⊱❥ *${prefix}bucin*
┣⊱❥ *${prefix}persengay*
┣⊱❥ *${prefix}ramalhp <nomor>*
┣⊱❥ *${prefix}ceckjodoh*
┃
┣━━━━━°❀ ❬ *ANIME* ❭ ❀°━━━━━┓
┃
┣⊱❥ *${prefix}openanime*
┣⊱❥ *${prefix}Naruto*
┣⊱❥ *${prefix}Minato*
┣⊱❥ *${prefix}Boruto*
┣⊱❥ *${prefix}Hinata*
┣⊱❥ *${prefix}Sakura*
┣⊱❥ *${prefix}Sasuke*
┣⊱❥ *${prefix}kaneki*
┣⊱❥ *${prefix}toukacan*
┣⊱❥ *${prefix}rize*
┣⊱❥ *${prefix}akira*
┣⊱❥ *${prefix}itori*
┣⊱❥ *${prefix}kurumi*
┣⊱❥ *${prefix}miku*
┣⊱❥ *${prefix}anime*
┣⊱❥ *${prefix}nekonime*
┣⊱❥ *${prefix}waifu*
┣⊱❥ *${prefix}waifu2*
┣⊱❥ *${prefix}wibu*
┣⊱❥ *${prefix}randomanime*
┣⊱❥ *${prefix}pokemon*
┣⊱❥ *${prefix}artinama*
┃
┣━━°❀ ❬ *INFO& EDUCACAO* ❭ ❀°━━━┓
┃
┣⊱❥ *${prefix}infogc*
┣⊱❥ *${prefix}infogempa*
┣⊱❥ *${prefix}infogithub*
┣⊱❥ *${prefix}infocuaca*
┣⊱❥ *${prefix}infonomor*
┣⊱❥ *${prefix}infomobil*
┣⊱❥ *${prefix}infomotor*
┣⊱❥ *${prefix}grupinfo*
┣⊱❥ *${prefix}lirik*
┣⊱❥ *${prefix}quotes*
┣⊱❥ *${prefix}cerpen*
┣⊱❥ *${prefix}chord*
┣⊱❥ *${prefix}wiki*
┣⊱❥ *${prefix}brainly*
┣⊱❥ *${prefix}resepmasakan*
┣⊱❥ *${prefix}map*
┃
┣━━━━━°❀ ❬ *GRUPO* ❭ ❀°━━━━━━┓
┃
┣⊱❥ *${prefix}add*
┣⊱❥ *${prefix}kick* ✓ remover um membro /kick e marque o membro
┣⊱❥ *${prefix}promote* /promote ✓ promover um membro adm marque o membro✓
┣⊱❥ *${prefix}demote*
┣⊱❥ *${prefix}setname* /setname ✓ alterar nome do grupo✓
┣⊱❥ *${prefix}setdesc* /setdesc ✓ apagar descric do grupo✓
┣⊱❥ *${prefix}welcome*
┣⊱❥ *${prefix}nsfw*
┣⊱❥ *${prefix}simih*
┣⊱❥ *${prefix}grup [buka/tutup]* ✓ grup buka (abre o grupo) grup tutup fecha o grupo✓
┣⊱❥ *${prefix}tagme*
┣⊱❥ *${prefix}hidetag*
┣⊱❥ *${prefix}tagall* /tagall ✓marcar todos membros do grupo inclusive adms✓
┣⊱❥ *${prefix}otagall*
┣⊱❥ *${prefix}fitnah*
┣⊱❥ *${prefix}infogc* ✓numero de adms e membros✓

┣⊱❥ *${prefix}grupinfo*
┣⊱❥ *${prefix}linkgrup*
┣⊱❥ *${prefix}listadmins*
┣⊱❥ *${prefix}openanime*
┣⊱❥ *${prefix}edotense*
┣⊱❥ *${prefix}kudeta*
┃
┣━━━━━°❀ ❬ *NSFW* ❭ ❀°━━━━━━┓
┃
┣⊱❥ *${prefix}nsfwblowjob*
┣⊱❥ *${prefix}nsfwneko*
┣⊱❥ *${prefix}nsfwtrap*
┣⊱❥ *${prefix}randomhentai*
┣⊱❥ *${prefix}hentai*
┣⊱❥ *${prefix}indohot*
┃
┣━━━━°❀ ❬ *Cartuchos* ❭ ❀°━━━━━┓
┃
┣⊱❥ *${prefix}apakah*
┣⊱❥ *${prefix}kapankah*
┣⊱❥ *${prefix}bisakah*
┣⊱❥ *${prefix}rate*
┣⊱❥ *${prefix}watak*
┣⊱❥ *${prefix}hobby*
┃
┣━━━━━°❀ ❬ *OUTROS* ❭ ❀°━━━━━┓
┃
┣⊱❥ *${prefix}blocklist* ✓ lista de contatos bloqueados pelo bot✓
┣⊱❥ *${prefix}testime* ✓hora do teste✓
┣⊱❥ *${prefix}hilih*
┣⊱❥ *${prefix}say*
┣⊱❥ *${prefix}delete*
┣⊱❥ *${prefix}shorturl*
┃
┣━━━━°❀ ❬ *PROPRIETARIO* ❭ ❀°━━━━━┓
┃
┣⊱❥ *${prefix}bc*
┣⊱❥ *${prefix}ban*
┣⊱❥ *${prefix}block*
┣⊱❥ *${prefix}unblock*
┣⊱❥ *${prefix}clearall*
┣⊱❥ *${prefix}clone* ✓clonar foto de alguém para usar no perfil do bot marque a pessoa✓
┣⊱❥ *${prefix}getses*
┣⊱❥ *${prefix}setpp*  ✓envie a foto com a legenda para mudar o icone do grupo✓
┣⊱❥ *${prefix}setpp*
┃
┣━━━━━°❀ ❬ *NOME* ❭ ❀°━━━━━┓
┃
┃ ╔══╦══╦══╦╗╔╦══╦╗
┃ ║═╦╣╔╗╠╗╗║╚╝╠║║╣║
┃ ║╔╝║╠╣╠╩╝║╔╗╠║║╣╚╗
┃ ╚╝─╚╝╚╩══╩╝╚╩══╩═╝
┃
┣━━━━°❀ *❬ SOSMED ❭* ❀°━━━━⊱
┃
┃ *Ha algum problema? Hub :*
┃ _http://wa.me/5522999982383_
┃ *Instagram :* @lordescreamocanal_
┃ *YouTube :*
┃ _Lorde Screamo_
┃ *Telegram :* @cafecyber_
┃
┣━━━━°❀ *❬ NOTA ❭* ❀°━━━━━━⊱
┃
┃Bot ini esta em desenvolvimento
┃Masih estamos trabalhando
┃Jadi obrigado tio do cafe.
┃
┣━━━━━°❀ ❬ *TQTO* ❭ ❀°━━━━━┛
┃
┃ *SPECIAL AGRADECA A lorde screamo :🤝*
┣━━━━━━━━━━━━━━━━━━━━┓
┃ *❬ POWERED BY TYODOCAFEBOT ❭*
┗━━━━━━━━━━━━━━━━━━━━┛`
}
exports.help = help
